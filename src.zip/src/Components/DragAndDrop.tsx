// src/components/DragAndDrop.tsx
"use client";

import React, { useEffect, useRef, useState } from "react";
import dragula from "dragula";
import "dragula/dist/dragula.css";

interface Section {
  id: string;
  name: string;
  tasks: string[];
}

interface DragAndDropProps {
  initialSections: Section[];
}

const DragAndDrop: React.FC<DragAndDropProps> = ({ initialSections }) => {
  const [sections, setSections] = useState<Section[]>(initialSections);
  const containerRefs = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const drake = dragula(containerRefs.current.filter(Boolean));

    drake.on("drop", (el: HTMLElement, target: HTMLElement, source: HTMLElement) => {
      const sourceId = source.dataset.sectionId;
      const targetId = target.dataset.sectionId;
      const task = el.textContent || "";

      if (sourceId && targetId) {
        setSections((prevSections) => {
          const updatedSections = [...prevSections];

          // Remove the task from the source section
          const sourceSection = updatedSections.find((s) => s.id === sourceId);
          if (sourceSection) {
            sourceSection.tasks = sourceSection.tasks.filter((t) => t !== task);
          }

          // Add the task to the target section
          const targetSection = updatedSections.find((s) => s.id === targetId);
          if (targetSection) {
            targetSection.tasks.push(task);
          }

          return updatedSections;
        });
      }
    });

    return () => drake.destroy();
  }, []);

  const addTask = (sectionId: string) => {
    const taskName = prompt("Enter a new task:");
    if (taskName) {
      setSections((prevSections) =>
        prevSections.map((section) =>
          section.id === sectionId
            ? { ...section, tasks: [...section.tasks, taskName] }
            : section
        )
      );
    }
  };

  return (
    <div style={{ display: "flex", gap: "1rem", padding: "20px" }}>
      {sections.map((section, index) => (
        <div
          key={section.id}
          ref={(el) => {
            if (el) containerRefs.current[index] = el;
          }}
          data-section-id={section.id}
          style={{
            border: "1px solid #ccc",
            padding: "10px",
            width: "200px",
            minHeight: "300px",
            backgroundColor: "#f9f9f9",
            borderRadius: "8px",
          }}
        >
          <h3 style={{ textAlign: "center" }}>{section.name}</h3>
          {section.tasks.map((task, taskIndex) => (
            <div
              key={taskIndex}
              style={{
                background: "#fff",
                margin: "5px 0",
                padding: "8px",
                borderRadius: "4px",
                boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
                cursor: "move",
              }}
            >
              {task}
            </div>
          ))}
          <button
            onClick={() => addTask(section.id)}
            style={{
              marginTop: "10px",
              background: "#007bff",
              color: "white",
              padding: "5px 10px",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
              width: "100%",
            }}
          >
            + Add Task
          </button>
        </div>
      ))}
    </div>
  );
};

export default DragAndDrop;
