// src/app/crm/[local]/page.tsx
import React from "react";
import DragAndDrop from "@/Components/DragAndDrop";

const CRMPage = ({ params }: { params: { local: string } }) => {
  // Example sections based on `local` param
  const initialSections = [
    { id: "new", name: "New", tasks: ["Lead 1", "Lead 2"] },
    { id: "qualified", name: "Qualified", tasks: ["Lead 3"] },
    { id: "proposition", name: "Proposition", tasks: [] },
    { id: "won", name: "Won", tasks: [] },
    { id: "stage", name: "Stage", tasks: [] },
  ];

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h1 style={{ textAlign: "center", marginBottom: "20px" }}>
        CRM Board for {params.local}
      </h1>
      <DragAndDrop initialSections={initialSections} />
    </div>
  );
};

export default CRMPage;
